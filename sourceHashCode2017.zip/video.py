class Video():

    def __init__(self, id, size):
        self.id = id
        self.size = size

